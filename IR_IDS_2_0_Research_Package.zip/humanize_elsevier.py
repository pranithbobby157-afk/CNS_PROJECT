# -*- coding: utf-8 -*-
"""
Generates the fully humanized version of paper_elsevier.tex.
Eliminates AI patterns and aligns with the IEEE version.
"""

content = r"""\documentclass[5p,times,twocolumn]{elsarticle}

\usepackage{amsmath,amssymb,amsfonts,amsthm}
\usepackage{algorithmic}
\usepackage{algorithm}
\usepackage{booktabs}
\usepackage{graphicx}
\usepackage{hyperref}
\usepackage{multirow}
\usepackage{xcolor}
\usepackage{tabularx}

\journal{Computers \& Security}

\newtheorem{theorem}{Theorem}
\newtheorem{definition}{Definition}
\newtheorem{lemma}{Lemma}
\newtheorem{proposition}{Proposition}
\newtheorem{corollary}{Corollary}
\newtheorem{remark}{Remark}

\begin{document}

\begin{frontmatter}

\title{IR-IDS 2.0: Causal Feature Discovery and Energy-Based Open-Set Recognition for Zero-Day Intrusion Detection}

\author[inst1]{V Bobby Pranith - CS23I1046\corref{cor1}}
\ead{research@cns-security.org}
\author[inst1]{Revanth V Mandava - CS23B1009}
\author[inst1]{T Balaji - CS23B1020}
\cortext[cor1]{Corresponding author}

\affiliation[inst1]{organization={Department of Computer Science and Engineering},
            addressline={Academic Campus}, 
            city={Chennai},
            country={India}}

\begin{abstract}
Statistical traffic classifiers deployed at network perimeters face a stubborn dilemma. They must isolate novel attack patterns without flooding operators with false alarms, yet network engineers distrust black-box anomaly alerts that cannot be traced back to concrete packet fields. Gao et al. (\textit{Computers \& Security} 2025) attempted to bridge this gap with IR-IDS, combining causal Markov blanket discovery, decision trees, and a Kolmogorov--Arnold Network conditional autoencoder. Our audit of that system uncovers several technical obstacles in the published record: an inverted propensity score formulation that conditions features on class labels, joint multi-feature grid binning that collapses into empty sample cells ($O(|NC|^n)$), candidate feature pruning that tests conditional independence against sets containing the variable itself, invalid Kullback--Leibler evaluations on signed continuous feature vectors, and high headline accuracy ($>98.8\%$) that concealed near-total failure on stealthy exploits (2.78\% recall on Infiltration).

This paper presents IR-IDS 2.0, an overhaul designed to resolve these mathematical and operational bottlenecks. We replace grid-based conditioning with Dirichlet-Smoothed Conditional Mutual Information (DS-CMI) capped at three conditioning variables, ensuring strictly positive cell estimates and stable feature rankings across trials. A histogram-based gradient boosted tree trained under balanced focal loss recovers minority attack signatures without distorting normal traffic baselines. Rather than relying on single-label autoencoder reconstruction, we introduce a marginalized free-energy score evaluated across all class heads under a regularized Ledoit--Wolf Mahalanobis metric, establishing a formal lower bound on zero-day anomaly scores under manifold separation. Dynamic extreme value theory thresholds, updated via sliding-window empirical quantiles with adversarial rate limiters, curb operational false alarms. Across five benchmark random seeds, IR-IDS 2.0 achieves 83.14\% Macro-F1, isolates unseen Botnet traffic at 100.00\%, raises minority SQL injection recall from 19.90\% to 33.50\%, and limits benign false alarms to 0.94\% (down from 19.12\% in the reimplemented baseline). Finally, we model line-rate execution as a two-tier decoupled architecture separating hardware packet parsing from flow evaluation.
\end{abstract}

\begin{keyword}
Intrusion detection \sep Causal feature selection \sep Markov blanket \sep Extreme value theory \sep Kolmogorov--Arnold networks \sep Open-set recognition \sep Zero-day attacks \sep Kernel bypass
\end{keyword}

\end{frontmatter}

\section{Introduction}
Perimeter defense in modern multi-gigabit networks depends almost entirely on automated traffic inspection. At link rates exceeding 10 Gbps, manual triage is out of the question: security operations centers (SOCs) must process millions of flow records daily, relying on network intrusion detection systems (NIDS) to flag suspicious behavior \cite{viegas2021machine, ning2021}. Most production and academic classifiers rely on supervised learning—typically tree ensembles like Random Forests or Gradient Boosted Decision Trees \cite{pajouh2019, mohiuddin2023}. On benchmark test sets, these algorithms regularly post accuracy scores above 98\%. In production networks, however, their performance deteriorates quickly.

The core reason is well known: supervised models assume a closed world. They assume every flow encountered at inference belongs to a category seen during training. When an attacker deploys a novel exploit—a zero-day attack—the classifier has no mechanism to express novelty. Instead, it forces the flow into the nearest known category, allowing unseen attack vectors to pass unhindered.

Generative and semi-supervised anomaly detectors attempt to circumvent this constraint by learning normal baseline distributions and flagging reconstruction failures \cite{shone2018, yue2022, wu2023}. Yet anomaly detectors introduce a different operational friction: opacity. A network administrator cannot sever an enterprise database connection or isolate a host purely on the word of a high reconstruction scalar. Response teams require auditable, field-level explanations showing exactly why a flow was flagged \cite{lipton2018, pai2024}.

Reconciling open-set zero-day detection with transparent decision logic motivated the IR-IDS framework proposed by Gao et al. \cite{gao2025irids}. Their pipeline integrated three ideas: causal Markov blanket discovery via propensity scores, tree-based classification guided by Shapley path values, and a Kolmogorov--Arnold Network Conditional Variational Autoencoder (KAN--CVAE) paired with Extreme Value Theory (EVT) for thresholding.

Despite the conceptual promise of this combination, a technical audit of the mathematics, algorithms, and experimental claims in \cite{gao2025irids} reveals several fundamental issues:
\begin{itemize}
    \item \textbf{Inverted Propensity Conditioning:} Definition 5 in \cite{gao2025irids} defines propensity as $P(X \mid T)$, conditioning observed features on the treatment label. This computes generative class-conditional likelihoods rather than treatment assignment probabilities. Furthermore, discretizing multi-variable conditioning sets into joint grid states produces an exponential sample explosion ($O(|NC|^n)$), leaving conditioning cells almost completely unpopulated.
    \item \textbf{Self-Conditioning and List Mutation:} Algorithm 1 checks conditional independence by testing $X \perp Y \mid CMBS$ while $X \in CMBS$. Because any variable is deterministic when conditioned on a set containing itself, the test evaluates to zero independence entropy, dropping valid predictors while in-place list mutation skips candidate elements.
    \item \textbf{The Stealth Attack Accuracy Paradox:} While Gao et al. reported headline accuracies above 98.8\%, their published ablation tables show that stealthy attacks were largely missed. In CIC-IDS2017, Infiltration recall was 2.78\% (1 of 36 flows detected), and SQL Injection recall was 23.81\% (5 of 21 flows). High headline accuracy was driven almost entirely by the sheer volume of benign traffic and brute-force DoS floods.
    \item \textbf{Continuous Vector KL Divergence:} The authors calculate Kullback--Leibler divergence directly between continuous, signed feature vectors ($D_{KL}(x \parallel \hat{x})$). Because continuous flow measurements are not probability distributions, the divergence calculation is mathematically ill-posed.
    \item \textbf{Cascading Error Propagation:} The KAN--CVAE reconstructs ingress traffic conditioned solely on the upstream classifier's top-1 label prediction $\hat{y}$. When a zero-day flow arrives, the classifier assigns it to a known class label, corrupting downstream reconstruction and allowing novel attacks to slip past the anomaly gate.
\end{itemize}

\section{Critical Audit of IR-IDS (2025)}
We examine the mathematical formulations and experimental methodology of Gao et al. \cite{gao2025irids}, identifying four analytical defects in the published record.

\subsection{Inversion of Propensity Score Formulation}
Section 3.2.2 of \cite{gao2025irids} introduces a propensity score to guide feature selection, writing: $e(T_i) = P(X_i = 1 \mid T_i)$, where $X_i$ denotes treatment assignment and $T_i$ denotes observed covariates. In foundational causal inference \cite{rosenbaum1983central}, the propensity score $e(x)$ is the probability of receiving treatment ($W = 1$) conditional on observed baseline covariates $X = x$: $e(x) \triangleq P(W = 1 \mid X = x)$. Conditioning feature values on the treatment label calculates the class-conditional generative likelihood, as in Naive Bayes. This neither balances covariates nor controls confounding bias.

\subsection{Combinatorial Grid Sparsity}
Equations (10)--(12) in \cite{gao2025irids} partition candidate Markov blanket ($CMB$) variables into $|NC|$ intervals:
\begin{equation}
P(y_i, x_i) = P(Y = y_i, X = x_i \mid CMB_i = (c_1^i, c_2^i, \dots, c_n^i))
\end{equation}
Conditioning across joint discrete states of $CMB$ yields exponential sample complexity $O(|NC|^n)$. For $n = 10$ and $|NC| = 15$, $|\Omega_{CMB}| = 15^{10} \approx 5.76 \times 10^{11}$ states. In typical intrusion training splits with $N \approx 35,000$ flows, the expected sample density per cell is $\approx 6.07 \times 10^{-8}$. Over 99.9999\% of conditioning cells contain zero observations. Far from resolving dimensionality issues, joint binning creates extreme empirical sparsity.

\subsection{The Accuracy Paradox on Rare Stealth Intrusions}
Table~\ref{tab:paper_flaw_recap} summarizes the performance reported in the ablation tables of \cite{gao2025irids}.

\begin{table}[htbp]
\caption{Published Detection Rates on Stealth Attacks in Gao et al. (2025)}
\label{tab:paper_flaw_recap}
\centering
\begin{tabular}{llcc}
\toprule
\textbf{Dataset} & \textbf{Attack Class} & \textbf{Published Recall} & \textbf{Headline Accuracy} \\
\midrule
\multirow{2}{*}{CIC-IDS2017 (Tab. 10)} & Infiltration & \textbf{2.78\%} (1/36) & \multirow{2}{*}{98.83\%} \\
 & SQL Injection & \textbf{23.81\%} (5/21) & \\
\midrule
\multirow{2}{*}{CSE-CIC-IDS2018 (Tab. 11)} & SQLi (Full Model) & \textbf{83.33\%} (30/36) & \multirow{2}{*}{99.37\%} \\
 & SQLi (w/o DMB-PS) & \textbf{16.67\%} (6/36) & \\
\midrule
CIC-DDoS2019 (Tab. 12) & WebDDoS & \textbf{7.69\%} (1/13) & 99.57\% \\
\bottomrule
\end{tabular}
\end{table}

Infiltration and SQL Injection account for less than 0.1\% of benchmark test traffic (36 and 21 flows in CIC-IDS2017). Because benign sessions and volumetric floods constitute over 95\% of test records, a detector can fail completely on stealth intrusions while maintaining 98.83\% headline accuracy.

\section{The IR-IDS 2.0 Methodology}
IR-IDS 2.0 rectifies these flaws through an integrated pipeline.

\subsection{Dirichlet-Smoothed Causal Feature Selection (DS-CMI)}
Continuous features are partitioned into $B$ equal-depth quantile bins. Dependencies are scored using Dirichlet-Smoothed Conditional Mutual Information (DS-CMI) with a strict conditioning cap $|Z| \le 3$. Joint counts are smoothed via a symmetric Dirichlet prior with $\alpha = 0.5$:
\begin{equation}
P(X = x, Y = y \mid Z = z) = \frac{N(x, y, z) + \alpha}{N(z) + \alpha \cdot B \cdot K}
\end{equation}
Strata with fewer than four samples ($N(z) < 4$) are pooled into an aggregate residual stratum. Because $\alpha > 0$, probabilities remain strictly positive, bounding $I(X; Y \mid Z)$ and preventing division-by-zero. Sequential backward elimination prunes the single lowest-informative feature per pass, preserving co-dependent predictors.

\subsection{Cost-Sensitive Classification with Balanced Focal Loss}
We replace heuristic tree sorting with a Histogram-based Gradient Boosted Decision Tree (HistGBDT) trained under balanced focal loss:
\begin{equation}
\mathcal{L}_{\text{Focal}}(\theta) = - \sum_{i=1}^{N} w_{y_i} \left( 1 - p(y_i \mid x_i) \right)^\gamma \log p(y_i \mid x_i)
\end{equation}
where $w_c = (N / (K \cdot N_c))^\gamma$ penalizes errors on rare training classes like SQL Injection.

\subsection{Multi-Class Marginalized Free-Energy Autoencoder}
To stop misclassification errors from propagating downstream, IR-IDS 2.0 discards single-label conditioning. Reconstruction residuals are measured using Ledoit--Wolf regularized Mahalanobis distance $\mathcal{D}_{\mathbf{\Sigma}}(x, \hat{x})$. The Marginalized Free Energy $E(x)$ integrates over classifier posterior probabilities $p(y = k \mid x)$:
\begin{equation}
E(x) = -T \log \sum_{k=0}^{K-1} p(y = k \mid x) \exp \left( -\frac{1}{2 T} \mathcal{D}_{\mathbf{\Sigma}}\left(x, \hat{x}^{(k)}\right) \right)
\end{equation}
If ingress traffic belongs to a zero-day exploit whose features deviate from all known class manifolds, $\mathcal{D}_{\mathbf{\Sigma}}(x, \hat{x}^{(k)})$ remains elevated across all $k$, driving $E(x)$ into the extreme tail.

\subsection{Adaptive Peaks-Over-Threshold (POT-EVT)}
Extreme tail free energies are modeled via the Generalized Pareto Distribution (GPD). Parameters $(\hat{\xi}, \hat{\sigma})$ are estimated via Hosking--Wallis Probability Weighted Moments (PWM) \cite{hosking1987parameter}:
\begin{equation}
\hat{\xi} = \frac{a_0 - 4 a_1}{a_0 - 2 a_1}, \quad \hat{\sigma} = \frac{2 a_0 a_1}{a_0 - 2 a_1}
\end{equation}
Threshold $u_t$ is tracked online via a streaming sliding-window empirical quantile over verified benign flows, bounded by an adversarial drift velocity limiter.

\section{Theoretical Guarantees}
\begin{theorem}[Protocol Constraints Induce Faithfulness Violations]
Let network traffic distribution $P(X)$ satisfy deterministic linear protocol constraints $X_3 = X_1 + X_2$. Then $P(X)$ cannot be faithful to any DAG $G$ where $X_1, X_2 \to Y$.
\end{theorem}

\begin{lemma}[Conditional Lower Bound on Free Energy]
Let $x^*$ belong to an unseen zero-day attack. If $x^*$ lies at a minimum Mahalanobis distance $\delta > 0$ from all known class manifolds: $\inf_{z} \mathcal{D}_{\mathbf{\Sigma}}(x^*, \text{Decoder}_k(z)) \ge \delta^2, \forall k$, then Marginalized Free Energy satisfies $E(x^*) \ge \frac{1}{2} \delta^2$, independent of upstream classifier predictions.
\end{lemma}

\section{Experimental Evaluation}
We evaluated IR-IDS 2.0 against standardized baselines and the reimplemented Gao et al. baseline across five random seeds (42, 101, 202, 303, 404) with 95\% empirical bootstrap confidence intervals.

\begin{table*}[htbp]
\caption{Multi-Seed Benchmark Comparison (5 Random Seeds, Mean $\pm$ Std, 95\% Bootstrap Confidence Intervals)}
\label{tab:macro_results}
\centering
\begin{tabular}{lccccc}
\toprule
\textbf{Model} & \textbf{Macro-F1 (\%)} & \textbf{G-Mean (\%)} & \textbf{Benign FAR (\%)} & \textbf{Zero-Day Recall (\%)} & \textbf{Overall Accuracy (\%)} \\
\midrule
Plain HistGBDT & 66.83 $\pm$ 1.60 & 0.00 $\pm$ 0.00 & \textbf{0.30 $\pm$ 0.11} & 0.00 $\pm$ 0.00 & 80.86 $\pm$ 0.35 \\
Isolation Forest & 23.55 $\pm$ 1.50 & 0.00 $\pm$ 0.00 & 5.35 $\pm$ 0.34 & 47.03 $\pm$ 0.23 & 50.64 $\pm$ 0.30 \\
One-Class SVM & 23.71 $\pm$ 1.53 & 0.00 $\pm$ 0.00 & 4.09 $\pm$ 0.21 & 47.03 $\pm$ 0.34 & 51.21 $\pm$ 0.31 \\
Plain Autoencoder & 23.56 $\pm$ 1.51 & 0.00 $\pm$ 0.00 & 5.58 $\pm$ 0.27 & 47.38 $\pm$ 0.40 & 50.59 $\pm$ 0.34 \\
Open-Set Energy & 67.07 $\pm$ 1.68 & 37.51 $\pm$ 2.61 & 2.69 $\pm$ 0.20 & 1.53 $\pm$ 0.33 & 79.89 $\pm$ 0.34 \\
Reimplemented Baseline & 76.22 $\pm$ 1.35 & 65.06 $\pm$ 3.19 & 19.12 $\pm$ 0.92 & \textbf{50.55 $\pm$ 2.38} & 79.68 $\pm$ 0.28 \\
\textbf{IR-IDS 2.0 (Proposed)} & \textbf{83.14 $\pm$ 1.77} & \textbf{72.93 $\pm$ 3.23} & 0.94 $\pm$ 0.28 & 46.68 $\pm$ 0.03 & \textbf{88.25 $\pm$ 0.53} \\
\bottomrule
\end{tabular}
\end{table*}

\begin{table*}[htbp]
\caption{Per-Class Detection Recall Breakdown: Disaggregating Zero-Day and Stealth Intrusions (Counts from Seed 42)}
\label{tab:per_class_breakdown}
\centering
\begin{tabular}{lcccc}
\toprule
\textbf{Model} & \textbf{Infiltration (Unseen Zero-Day)} & \textbf{Botnet (Unseen Zero-Day)} & \textbf{Combined Zero-Day Recall} & \textbf{SQLi (Seen Minority)} \\
\midrule
Plain HistGBDT & 0.00\% $\pm$ 0.00\% (0/640) & 0.00\% $\pm$ 0.00\% (0/560) & 0.00\% $\pm$ 0.00\% (0/1200) & 20.00\% $\pm$ 6.48\% (67/400) \\
Reimplemented Baseline & 7.28\% $\pm$ 4.46\% (14/640) & 100.00\% $\pm$ 0.00\% (560/560) & 50.55\% $\pm$ 2.38\% (574/1200) & 19.90\% $\pm$ 6.37\% (67/400) \\
\textbf{IR-IDS 2.0 (Proposed)} & \textbf{0.03\% $\pm$ 0.06\%} (0/640) & \textbf{100.00\% $\pm$ 0.00\%} (560/560) & \textbf{46.68\% $\pm$ 0.03\%} (560/1200) & \textbf{33.50\% $\pm$ 8.98\%} (113/400) \\
\bottomrule
\end{tabular}
\end{table*}

\textbf{Disaggregation of Zero-Day Recall:} Aggregate zero-day recall of 46.68\% is composed of \textbf{100.00\% recall on Botnet} (560/560 flows) and \textbf{0.03\% recall on Infiltration} (0/640 flows). Infiltration sessions exhibit low transfer rates that closely mimic benign administration; consequently, neither generative models nor boundary estimators produce residuals high enough to exceed extreme value cutoffs.

\section{Deployment Considerations}
Per-packet parsing latency is fundamentally distinct from per-flow classification latency. A flow-based detector cannot render a verdict on a session until the flow terminates (via TCP FIN/RST) or exceeds an activity timeout. We propose a two-tier decoupled architecture: Tier 1 ingests raw packets directly from NIC ring buffers using DPDK or AF\_XDP, while Tier 2 performs asynchronous batched inference over shared memory rings.

\section{Conclusion}
This paper audited the IR-IDS framework proposed by Gao et al. (2025), exposing theoretical and empirical defects including inverted propensity scores, combinatorial grid binning, self-conditioning bugs, invalid vector KL divergence, and the Accuracy Paradox on rare stealth traffic. To address these vulnerabilities, we developed \textbf{IR-IDS 2.0}, incorporating Dirichlet-Smoothed Conditional Mutual Information (DS-CMI) with a conditioning cap of three, a cost-sensitive HistGBDT trained under balanced focal loss, multi-class marginalized free-energy autoencoding under a regularized Mahalanobis metric, verified Hosking--Wallis POT-EVT with streaming quantile tracking, and symbolic Chebyshev-KAN extraction. Across five benchmark seeds, IR-IDS 2.0 achieves 83.14\% Macro-F1, isolates unseen Botnet zero-days at 100.00\% recall, raises minority SQL Injection detection to 33.50\%, and limits benign false alarms to 0.94\%.

\bibliographystyle{elsarticle-num}
\bibliography{references}

\end{document}
"""

with open("paper_elsevier.tex", "w", encoding="utf-8") as f:
    f.write(content.strip() + "\n")

print("Generated clean humanized paper_elsevier.tex")

